Data consists of 2 files of peptides from MHC A0201 and a BLOSUM50 matrix.
