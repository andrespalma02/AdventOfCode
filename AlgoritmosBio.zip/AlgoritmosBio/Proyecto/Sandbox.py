a=set()
b=frozenset()